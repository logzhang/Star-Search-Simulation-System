public enum SquareType {
    EMPTY,
    STAR,
    SUN,
    DRONE
}
