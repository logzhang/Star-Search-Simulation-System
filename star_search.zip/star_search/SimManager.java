import java.util.Scanner;
import java.util.HashMap;
import java.util.Random;

public class SimManager {
    private static Random randGenerator;
    private HashMap<String, Integer> xDIR_MAP;
    private HashMap<String, Integer> yDIR_MAP;
    private String trackAction;
    private String trackNewDirection;
    private Integer trackThrustDistance;
    private String trackMoveCheck;
    private String trackScanResults;
    private final String[] ORIENT_LIST = {"north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest"};
    private Space space;
    private Drone[] drones;
    private Integer turnLimit;
    private Integer numberOfDrones;


    public SimManager(String fileName) {
        randGenerator = new Random();
        space = new Space (fileName);
        drones = space.getDrones();
        turnLimit = space.getTurnLimit();
        numberOfDrones = space.getNumberOfDrones();

        xDIR_MAP = new HashMap<>();
        xDIR_MAP.put("north", 0);
        xDIR_MAP.put("northeast", 1);
        xDIR_MAP.put("east", 1);
        xDIR_MAP.put("southeast", 1);
        xDIR_MAP.put("south", 0);
        xDIR_MAP.put("southwest", -1);
        xDIR_MAP.put("west", -1);
        xDIR_MAP.put("northwest", -1);

        yDIR_MAP = new HashMap<>();
        yDIR_MAP.put("north", 1);
        yDIR_MAP.put("northeast", 1);
        yDIR_MAP.put("east", 0);
        yDIR_MAP.put("southeast", -1);
        yDIR_MAP.put("south", -1);
        yDIR_MAP.put("southwest", -1);
        yDIR_MAP.put("west", 0);
        yDIR_MAP.put("northwest", 1);

        }

    public Integer simulationDuration() {
        return turnLimit;
    }

    public Integer droneCount() {
        return numberOfDrones;
    }

    public void pollDroneForAction(int id) {
        int moveRandomChoice, thrustRandomChoice, steerRandomChoice;

        if (drones[id].getDroneStrategy() == 2 ) {
            Scanner askUser = new Scanner(System.in);
            // generate a move by asking the user - DIAGNOSTIC ONLY
            System.out.print("action?: ");
            trackAction = askUser.nextLine();

            if (trackAction.equals("steer")) {
                System.out.print("direction?: ");
                trackNewDirection = askUser.nextLine();
            } else if (trackAction.equals("thrust")) {
                System.out.print("distance?: ");
                trackThrustDistance = Integer.parseInt(askUser.nextLine());
            }
        }
        else if (drones[id].getDroneStrategy() == 1 ) {
            Action action = drones[id].getNextAction();
//            System.out.println("Action:" + action);
            switch (action) {
                case PASS:
                    trackAction = "pass";
                    break;
                case SCAN:
                    trackAction = "scan";
                    break;
                case STEER:
                    trackAction = "steer";
                    trackNewDirection = drones[id].getDroneNextDirection();
                    break;
                case THRUST:
                    trackAction = "thrust";
                    trackThrustDistance = drones[id].getThrustSteps();
                    break;
            }
        }
        else {
            // generate a move randomly
            moveRandomChoice = randGenerator.nextInt(100);
            if (moveRandomChoice < 5) {
                // do nothing
                trackAction = "pass";
            } else if (moveRandomChoice < 20) {
                // check your surroundings
                trackAction = "scan";

            } else if (moveRandomChoice < 50) {
                // change direction
                trackAction = "steer";


            } else {
                // thrust forward
                trackAction = "thrust";
                thrustRandomChoice = randGenerator.nextInt(3);
                trackThrustDistance = thrustRandomChoice + 1;
            }

            // determine a new direction
            steerRandomChoice = randGenerator.nextInt(8);
            if (trackAction.equals("steer")) {
                trackNewDirection = ORIENT_LIST[steerRandomChoice];
            }
        }
    }

    public void validateDroneAction(int id) {
        int xOrientation, yOrientation;

        if (trackAction.equals("scan")) {
            // in the case of a scan, return the information for the eight surrounding squares
            // always use a northbound orientation
            trackScanResults = scanAroundSquare(drones[id].getDroneX(), drones[id].getDroneY());
            drones[id].setDroneScanResult(trackScanResults);
            trackMoveCheck = "ok";

        } else if (trackAction.equals("pass")) {
            trackMoveCheck = "ok";

        } else if (trackAction.equals("steer")) {
            drones[id].setDroneDirection(trackNewDirection);
            trackMoveCheck = "ok";

        } else if (trackAction.equals("thrust")) {
            // in the case of a thrust, ensure that the move doesn't cross suns or barriers
            xOrientation = xDIR_MAP.get(drones[id].getDroneDirection());
            yOrientation = yDIR_MAP.get(drones[id].getDroneDirection());

            trackMoveCheck = "ok";
            int remainingThrust = trackThrustDistance;

            while (remainingThrust > 0 && trackMoveCheck.equals("ok")) {

                int newSquareX = drones[id].getDroneX() + xOrientation;
                int newSquareY = drones[id].getDroneY() + yOrientation;

                if (newSquareX < 0 || newSquareX >= space.getRegionWidth() || newSquareY < 0 || newSquareY >= space.getRegionHeight()) {
                    // drone hit a barrier and simply doesn't move (do nothing)
                    if (newSquareX < 0 ) {
                        newSquareX = space.getRegionWidth() - 1;
                    } else if (newSquareX >= space.getRegionWidth()){
                        newSquareX = 0;
                    }
                    if (newSquareY < 0 ) {
                        newSquareY = space.getRegionHeight() - 1;
                    } else if (newSquareY >= space.getRegionHeight()) {
                        newSquareY = 0;
                    }
                    int preX = drones[id].getDroneX();
                    int preY = drones[id].getDroneY();
                    drones[id].setDroneX(newSquareX);
                    drones[id].setDroneY(newSquareY);
                    drones[id].afterThrust(preX, preY, newSquareX, newSquareY);

                    trackMoveCheck = "ok";

                } else if (space.getRegionInfo(newSquareY, newSquareX).squareType == SquareType.SUN) {
                    // drone hit a sun
                    drones[id].setDroneState(DroneState.CRASH);
                    trackMoveCheck = "crash";


                } else {

                    for (int i = 0; i < droneCount(); i++) {
                        if (id!=i) {
                            if (newSquareX == drones[i].getDroneX() && newSquareY == drones[i].getDroneY()) {
                                drones[id].setDroneState(DroneState.CRASH);
                                drones[i].setDroneState(DroneState.CRASH);
                                trackMoveCheck = "crash";
                                break;
                            }
                        }

                    }
                    if (!trackMoveCheck.equals("crash")) {
                        // drone thrust is successful
                        int preX = drones[id].getDroneX();
                        int preY = drones[id].getDroneY();
                        drones[id].setDroneX(newSquareX);
                        drones[id].setDroneY(newSquareY);
                        drones[id].afterThrust(preX, preY, newSquareX, newSquareY);
                        // update region status
                        space.getRegionInfo(newSquareY, newSquareX).squareType = SquareType.EMPTY;
                    }
                }

                remainingThrust = remainingThrust - 1;
            }

        } else {
            // in the case of an unknown action, treat the action as a pass
            trackMoveCheck = "action_not_recognized";
        }
    }

    public String scanAroundSquare(int targetX, int targetY) {
        String resultString = "";

        for (int k = 0; k < ORIENT_LIST.length; k++) {
            String nextSquare = "";
            String lookThisWay = ORIENT_LIST[k];
            int offsetX = xDIR_MAP.get(lookThisWay);
            int offsetY = yDIR_MAP.get(lookThisWay);

            int checkX = targetX + offsetX;
            int checkY = targetY + offsetY;

            if (checkX < 0) {
                checkX = space.getRegionWidth() - 1;
            }else if (checkX >= space.getRegionWidth()) {
                checkX = 0;
            }

            if (checkY < 0) {
                checkY = space.getRegionHeight() - 1;
            }else if (checkY >= space.getRegionHeight()) {
                checkY = 0;
            }

            for (int i = 0; i < droneCount(); i++) {
                if (drones[i].getDroneX() == checkX && drones[i].getDroneY() == checkY && drones[i].getDroneState() == DroneState.OK) {
                    nextSquare = "drone";
                    break;
                }
            }
            if (!nextSquare.equals("drone")) {
                switch (space.getRegionInfo(checkY, checkX).squareType) {
                    case EMPTY:
                        nextSquare = "empty";
                        break;
                    case STAR:
                        nextSquare = "stars";
                        break;
                    case SUN:
                        nextSquare = "sun";
                        break;
                    default:
                        nextSquare = "unknown";
                        break;
                    }
                }
            if (resultString.isEmpty()) { resultString = nextSquare; }
            else { resultString = resultString + "," + nextSquare; }
        }

        return resultString;
    }

    public void displayActionAndResponses(int id) {
        // display the drone's actions
        System.out.print("d" + String.valueOf(id) + "," + trackAction);
        if (trackAction.equals("steer")) {
            System.out.println("," + trackNewDirection);
        } else if (trackAction.equals("thrust")) {
                System.out.println("," + trackThrustDistance);
        } else {
            System.out.println();
        }

        // display the simulation checks and/or responses
        if (trackAction.equals("thrust") || trackAction.equals("steer") || trackAction.equals("pass")) {
            System.out.println(trackMoveCheck);
        } else if (trackAction.equals("scan")) {
            System.out.println(trackScanResults);
        } else {
            System.out.println("action_not_recognized");
        }
    }

    private void renderHorizontalBar(int size) {
        System.out.print(" ");
        for (int k = 0; k < size; k++) {
            System.out.print("-");
        }
        System.out.println("");
    }

    public void renderRegion() {
        int i, j;
        int charWidth = 2 * space.getRegionWidth() + 2;

        // display the rows of the region from top to bottom
        for (j = space.getRegionHeight() - 1; j >= 0; j--) {
            renderHorizontalBar(charWidth);

            // display the Y-direction identifier
            System.out.print(j);

            // display the contents of each square on this row
            for (i = 0; i < space.getRegionWidth(); i++) {
                System.out.print("|");

                // the drone overrides all other contents
                if (drones[0].getDroneState() == DroneState.OK && i == drones[0].getDroneX() && j == drones[0].getDroneY()) {
                    System.out.print("0");
                }
                else if (droneCount() > 1 && drones[1].getDroneState() == DroneState.OK && i == drones[1].getDroneX() && j == drones[1].getDroneY()) {
                    System.out.print("1");
               }
                else if (droneCount() > 2 && drones[2].getDroneState() == DroneState.OK && i == drones[2].getDroneX() && j == drones[2].getDroneY()) {
                    System.out.print("2");
                }
                else {
                    switch (space.getRegionInfo(j,i).squareType) {
                        case EMPTY:
                            System.out.print(" ");
                            break;
                        case STAR:
                            System.out.print(".");
                            break;
                        case SUN:
                            System.out.print("s");
                            break;
                        default:
                            break;
                    }
                }
            }
            System.out.println("|");
        }
        renderHorizontalBar(charWidth);

        // display the column X-direction identifiers
        System.out.print(" ");
        for (i = 0; i < space.getRegionWidth(); i++) {
            System.out.print(" " + i);
        }
        System.out.println("");

        // display the drone's directions
        for(int k = 0; k < droneCount(); k++) {
            if (drones[k].getDroneState() == DroneState.CRASH) { continue; }
            System.out.println("dir d" + String.valueOf(k) + ": " + drones[k].getDroneDirection());
        }
        System.out.println("");
    }

    public Boolean dronesAllStopped() {
        for(int k = 0; k < droneCount(); k++) {
            if (drones[k].getDroneState() == DroneState.OK) { return Boolean.FALSE; }
        }
        return Boolean.TRUE;
    }

    public Boolean droneStopped(int id) {
        return drones[id].getDroneState() == DroneState.CRASH;
    }

    public void finalReport(int completeTurns) {
        int regionSize = space.getRegionWidth() * space.getRegionHeight();
        int numSuns = 0;
        int numStars = 0;
        for (int i = 0; i < space.getRegionHeight(); i++) {
            for (int j = 0; j < space.getRegionWidth(); j++) {
                if (space.getRegionInfo(i,j).squareType == SquareType.SUN) { numSuns++; }
                if (space.getRegionInfo(i,j).squareType == SquareType.STAR) { numStars++; }
            }
        }
        int potentialCut = regionSize - numSuns;
        int actualCut = potentialCut - numStars;
//        System.out.println("numStars"+numStars);
        System.out.println(String.valueOf(regionSize) + "," + String.valueOf(potentialCut) + "," + String.valueOf(actualCut) + "," + String.valueOf(completeTurns));
    }

}