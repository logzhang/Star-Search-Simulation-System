import java.util.Objects;

public class Square {
    public Integer x;
    public Integer y;
    public SquareType squareType;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Square square = (Square) o;
        return Objects.equals(x, square.x) &&
                Objects.equals(y, square.y);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}
