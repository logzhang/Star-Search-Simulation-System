public enum Action {
    PASS,
    SCAN,
    STEER,
    THRUST
}
