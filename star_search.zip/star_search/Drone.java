import java.util.Set;

public class Drone {

    private Integer droneX, droneY;
    private DroneState droneState;
    private String droneDirection;
    private Integer droneStrategy;
    private DroneService droneService = DroneService.getInstance();
    private int thrustSteps = 0;
    private String droneNextDirection = "";



    public String getDroneNextDirection () {
        return droneNextDirection;
    }

    public int getThrustSteps() {
        return thrustSteps;
    }

    public Integer getDroneX() {
        return droneX;
    }

    public void setDroneX(Integer droneX) {
        this.droneX = droneX;
    }

    public Integer getDroneY() {
        return droneY;
    }

    public void setDroneY(Integer droneY) {
        this.droneY = droneY;
    }

    public DroneState getDroneState() {
        return droneState;
    }

    public void setDroneState(DroneState droneState) {
        this.droneState = droneState;
    }

    public String getDroneDirection() {
        return droneDirection;
    }

    public void setDroneDirection(String droneDirection) {
        this.droneDirection = droneDirection;
    }

    public Integer getDroneStrategy() {
        return droneStrategy;
    }

    public void setDroneStrategy(Integer droneStrategy) {
        this.droneStrategy = droneStrategy;
    }


    public void afterThrust(int preX, int preY, int newX, int newY) {
        droneService.updateSquare(preX, preY, SquareType.EMPTY);
        droneService.updateSquare(newX, newY, SquareType.DRONE);

    }


    public void setDroneScanResult(String scanResult) {
        droneService.syncData(scanResult, droneX, droneY);
    }

    public Action getNextAction() {
        String[] direction = {"north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest"};
        int thrustSteps = 0;
        int countOfKnownSquare = 0;
        directionLoop:for (int i = 0; i < 8; i++) {
            int newX = droneX + Constant.xArr[i];
            int newY = droneY + Constant.yArr[i];
            Set<Square> set = droneService.getScanMap();

            for (Square square : set) {
                if (square.x == newX && square.y == newY) {
                    countOfKnownSquare++;
                    if (square.squareType == SquareType.SUN || square.squareType == SquareType.DRONE ) {
                        continue directionLoop;
                    } else if (square.squareType == SquareType.STAR) {
                        thrustSteps++;
                        int nextX = newX;
                        int nextY = newY;
                        for (int j = 0; j < 2; j++) {
                            nextX = nextX + Constant.xArr[i];
                            nextY = nextY + Constant.yArr[i];
//                            System.out.println("nextX:" + nextX + "nextY:" + nextY);
                            if (checkNextSquare(set, nextX, nextY)) {
                                thrustSteps++;
                            }else {
                                break;
                            }
                        }
                        if (direction[i].equals(droneDirection)) {
                            this.thrustSteps = thrustSteps;
                            return Action.THRUST;
                        }else {
                            this.droneNextDirection = direction[i];
                            return Action.STEER;
                        }
                    }
                }

            }
        }
        if (countOfKnownSquare < 8) {
            return Action.SCAN;
        }else {
            return Action.PASS;
        }
    }

    public boolean checkNextSquare (Set<Square> set, int nextX, int nextY) {
        for (Square square : set) {

            if (square.x == nextX && square.y == nextY && square.squareType == SquareType.STAR) {
//                System.out.println("SquareType:" + square.squareType);
                return true;
            }
        } return false;
    }

}

