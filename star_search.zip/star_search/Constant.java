public class
Constant {
    public static int[] xArr = {0,1,1,1,0,-1,-1,-1};
    public static int[] yArr = {1,1,0,-1,-1,-1,0,1};
}
