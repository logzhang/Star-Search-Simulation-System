import java.io.File;
import java.util.Scanner;

public class Space {
    private Integer regionWidth;
    private Integer regionHeight;
    private Square[][] regionInfo;
    private Integer numberOfDrones;
    private final int MAX_DRONES = 3;
    private Drone[] drones = new Drone[MAX_DRONES];
    private Integer turnLimit;

    public Space(String testFileName) {
        uploadStartingFile(testFileName);
    }

    private void uploadStartingFile(String testFileName) {
        final String DELIMITER = ",";

        try {
            Scanner takeCommand = new Scanner(new File(testFileName));
            String[] tokens;
            int i, j, k;

            // read in the region information
            tokens = takeCommand.nextLine().split(DELIMITER);
            regionWidth = Integer.parseInt(tokens[0]);
            tokens = takeCommand.nextLine().split(DELIMITER);
            regionHeight = Integer.parseInt(tokens[0]);

            // generate the region information
            regionInfo = new Square[regionHeight][regionWidth];


            for (i = 0; i < regionHeight; i++) {
                for (j = 0; j < regionWidth; j++) {
                    regionInfo[i][j] = new Square();
                    regionInfo[i][j].squareType = SquareType.STAR;
                }
            }

            // read in the drone starting information
            tokens = takeCommand.nextLine().split(DELIMITER);
            numberOfDrones = Integer.parseInt(tokens[0]);
            for (k = 0; k < numberOfDrones; k++) {
                tokens = takeCommand.nextLine().split(DELIMITER);

                Drone drone = new Drone();

                drone.setDroneX(Integer.parseInt(tokens[0]));
                drone.setDroneY(Integer.parseInt(tokens[1]));
                drone.setDroneDirection(tokens[2]);
                drone.setDroneStrategy(Integer.parseInt(tokens[3]));
                drone.setDroneState(DroneState.OK);

                drones[k] = drone;
                // explore the stars at the initial location
                regionInfo[drone.getDroneX()][drone.getDroneY()].squareType = SquareType.EMPTY;
            }

            // read in the sun information
            tokens = takeCommand.nextLine().split(DELIMITER);
            int numSuns = Integer.parseInt(tokens[0]);
            for (k = 0; k < numSuns; k++) {
                tokens = takeCommand.nextLine().split(DELIMITER);

                // place a sun at the given location
                regionInfo[Integer.parseInt(tokens[1])][Integer.parseInt(tokens[0])].squareType = SquareType.SUN;
            }

            tokens = takeCommand.nextLine().split(DELIMITER);
            turnLimit = Integer.parseInt(tokens[0]);

            takeCommand.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println();
        }
    }



    public Integer getRegionWidth() {
        return regionWidth;
    }

    public Integer getRegionHeight() {
        return regionHeight;
    }

    public Square getRegionInfo(Integer RegionHeight, Integer RegionWeight) {
        return regionInfo[RegionHeight][RegionWeight];
    }

    public Drone[] getDrones() {
        return drones;
    }

    public Integer getTurnLimit() {
        return turnLimit;
    }

    public Integer getNumberOfDrones() {
        return numberOfDrones;
    }

}
