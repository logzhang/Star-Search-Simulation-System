public enum DroneState {
    OK,
    CRASH
}
