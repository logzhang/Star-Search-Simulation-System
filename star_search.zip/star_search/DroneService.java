import java.util.HashSet;
import java.util.Set;

public class DroneService {
    Set<Square> set = new HashSet<>();

    private static DroneService instance;

    public static synchronized DroneService getInstance() {
        if (instance == null) {
            instance = new DroneService();
        }
        return instance;
    }

    // offset int x and int y
    private DroneService () {
    }

    public void syncData (String droneScanResult, int x, int y) {
        String[] scanResultArr = droneScanResult.split(",");
        for (int i = 0; i < scanResultArr.length; i++ ) {
            Square square = new Square();
            square.x = x + Constant.xArr[i];
            square.y = y + Constant.yArr[i];
            square.squareType = getSquareType(scanResultArr[i]);
            set.add(square);

        }
    }

    public Set<Square> getScanMap() {
        return set;
    }

    public void updateSquare(int x, int y, SquareType type) {
        boolean findSquare = false;
        for (Square square : set ) {
            if (square.x == x && square.y == y ) {
                square.squareType = type;
                findSquare = true;
            }
        }
        if (!findSquare) {
            Square square = new Square();
            square.x = x;
            square.y = y;
            square.squareType = type;
            set.add(square);
        }

    }

    public SquareType getSquareType (String oneResult) {
        switch (oneResult) {
            case "drone":
                return SquareType.DRONE;
            case "stars":
                return SquareType.STAR;
            case "empty":
                return SquareType.EMPTY;
            case "sun":
                return SquareType.SUN;
        }
        return null;
    }

}
